@echo off
setlocal
where kmc >nul 2>nul
if errorlevel 1 (
  echo Keyman Compiler (kmc) was not found.
  echo Install Node.js 20 or later, then run: npm install --global @keymanapp/kmc
  exit /b 1
)
cd /d "%~dp0source"
kmc build .
if errorlevel 1 exit /b %errorlevel%
echo.
echo Build finished. Check the source\build folder.
pause
