# K'Cho Keyboard — reusable source project

This project contains the supplied K'Cho keyboard source files and a GitHub Actions workflow for compiling them with the official Keyman command-line compiler (`kmc`).

## Important: this is the source/build template

- The original keyboard rules and touch layout are preserved.
- Author, Copyright, and Description are intentionally left for each buyer/release to fill in later.
- The generic `Copyright ©` placeholder was removed from the keyboard source.
- The missing `k_cho_keyboard.ico` reference was removed so the project does not depend on an absent icon file.
- No buyer-specific package metadata or `.kps` package source is included yet.

**This ZIP is not an installable `.kmp` package.** It is the editable source project and automated keyboard compilation setup. A buyer-specific `.kps` package source and its metadata should be prepared when the buyer provides their Author, Copyright, Description, language display name/tag, and release details.

## Files

```text
KCho-Keyboard-Source/
├── .github/workflows/build.yml
├── .vscode/tasks.json
├── reference/
│   └── k_cho_keyboard-previous-build.js
├── source/
│   ├── k_cho_keyboard.kmn
│   ├── k_cho_keyboard.kpj
│   ├── k_cho_keyboard.kvks
│   └── k_cho_keyboard.keyman-touch-layout
├── build-windows.bat
└── README.md
```

The JavaScript file under `reference/` is the previously generated output supplied with the original ZIP. It is kept only as a reference; edit the `.kmn` and layout source files, not that generated file.

## Build on GitHub

1. Create a GitHub repository and upload the contents of this folder.
2. Push to the `main` or `master` branch, or open **Actions** and run **Build K'Cho Keyboard** manually.
3. Open the completed workflow run and download the `k-cho-keyboard-build` artifact.

GitHub installs Node.js 20 and the official `@keymanapp/kmc` compiler, then runs `kmc build .` in the `source` folder.

## Build locally on Windows

1. Install Node.js 20 or later.
2. Open Command Prompt and run:

   ```bash
   npm install --global @keymanapp/kmc
   ```

3. Double-click `build-windows.bat`, or run this in a terminal:

   ```bash
   cd source
   kmc build .
   ```

The compiler writes build outputs under the project build folder. The exact output set depends on the Keyman compiler version and project targets.

## Edit in Visual Studio Code

Open this folder in Visual Studio Code. Edit:

- `source/k_cho_keyboard.kmn` for keyboard rules and character mappings.
- `source/k_cho_keyboard.keyman-touch-layout` for touch layout.
- `source/k_cho_keyboard.kvks` for the visual keyboard.

Install `kmc` as described above, then use **Terminal → Run Task → Build K'Cho Keyboard with Keyman Compiler**.

Visual Studio Code is recommended for this source workflow. Full visual editing of Keyman layouts still requires a compatible Keyman editing tool; this project makes the text source editable without relying on the Keyman Developer graphical editor.

## Buyer-specific release checklist

When preparing a buyer's package, collect and add the buyer's requested:

- Author
- Copyright holder/text
- Description
- Language display name and BCP 47 language tag (confirm the exact Windows language-switcher display)
- Package version and package name

Then create/update the `.kps` package source and build the installable `.kmp` with `kmc`. Do not reuse one buyer's metadata for another buyer.

## Compiler reference

Official Keyman `kmc` documentation: https://help.keyman.com/developer/current-version/reference/kmc/cli/get-started
