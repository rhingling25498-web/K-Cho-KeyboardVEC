# K'Cho Keyboard — reusable source project

This is the reusable source project for the K'Cho Keyboard. It includes the original keyboard rules/layout, the custom keyboard icon, a Keyman package source template, and GitHub Actions automation.

## Language and Windows display

The package source `source/k_cho_keyboard.kps` associates the keyboard with BCP 47 language tag `mwq` and language label `Mün Chin`. It does **not** associate the keyboard with `en-US` / English (United States). The intended Windows language-switcher entry is:

- **Mün Chin**
- **K'Cho Keyboard**

Windows/Keyman may normalize or display language labels according to the installed Windows language resources. Confirm the final wording on the target PC after installing the newly built `.kmp`.

## Icon

`source/k_cho_keyboard.ico` is the custom K'Cho icon and contains 16, 32, 48, 64, 128, and 256 pixel images. The keyboard source references it through `&BITMAP`.

## Buyer-specific metadata

The reusable template intentionally leaves these package fields blank:

- Author
- Copyright
- Description

When preparing a buyer's release, fill those fields in `source/k_cho_keyboard.kps` using that buyer's supplied details. Do not carry one buyer's details into another buyer's copy. The package's technical name and keyboard version are already set to `K'Cho Keyboard` and `1.0.3` respectively; update the version as appropriate for each release.

## Build on GitHub

1. Upload the contents of this folder to the root of a GitHub repository (including the `.github` folder).
2. Push to `main` or `master`, or run the workflow manually from **Actions**.
3. Download the artifact **KCho-Keyboard-Mun-Chin** from the completed workflow run.
4. Install `k_cho_keyboard.kmp` in Keyman for Windows for the language association to be applied. Do not test language registration by installing only the standalone `.kmx` file, because the BCP 47 association is package metadata.

The workflow installs the official `@keymanapp/kmc` command-line compiler, builds the keyboard, then builds the `.kps` package. It verifies that the `.kmp` output exists and prints the package metadata for inspection.

## Build locally on Windows

1. Install Node.js 20 or later.
2. Open Command Prompt and run:

   ```bash
   npm install --global @keymanapp/kmc
   ```

3. Run `build-windows.bat` from this folder, or execute:

   ```bash
   cd source
   kmc build k_cho_keyboard.kmn
   kmc build k_cho_keyboard.kps
   ```

The outputs are written under `source/build/`.

## Edit in Visual Studio Code

Open this folder in Visual Studio Code. Edit:

- `source/k_cho_keyboard.kmn` for keyboard rules and the icon reference.
- `source/k_cho_keyboard.keyman-touch-layout` for touch layout.
- `source/k_cho_keyboard.kvks` for the desktop visual keyboard.
- `source/k_cho_keyboard.kps` for package language and buyer-specific package metadata.

The source is text-editable in VS Code. The Keyman Developer graphical editor is not required for command-line compilation.
