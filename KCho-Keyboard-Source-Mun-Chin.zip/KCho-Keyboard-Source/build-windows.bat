@echo off
setlocal
cd /d "%~dp0source"
where kmc >nul 2>nul
if errorlevel 1 (
  echo Keyman compiler (kmc) was not found.
  echo Install Node.js, then run: npm install --global @keymanapp/kmc
  pause
  exit /b 1
)
kmc build k_cho_keyboard.kmn
if errorlevel 1 goto :error
kmc build k_cho_keyboard.kps
if errorlevel 1 goto :error
echo.
echo Build complete. Check sourceuild for the KMP package.
pause
exit /b 0
:error
echo.
echo Build failed. Read the compiler error above.
pause
exit /b 1
